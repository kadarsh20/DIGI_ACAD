$( ".course" ).click(function() {
  let all_course = document.querySelector(".subject");
  all_course.classList.add("inActive");

  let course_id = $(this).attr('id');
  let clicked_course = document.querySelector("."+course_id);
  clicked_course.classList.remove(course_id);
});

function renderData(id) {
  
  let course_details = document.querySelector(".course-content");
  course_details.classList.add("inActive");
  const btn1 = document.getElementById("file-upload");
  const btn2 = document.getElementById("form-submit");
  btn1.className = "file-upload";
  btn2.className = "form-submit";

  const details = {
    "c1-q1": {
        heading: "Quiz-1",
        startDate: "26/3/2022",
        endDate: "26/3/2022",
        instructions: "This is a closed notes examination"
    },
    "c1-q2": {
        heading: "Quiz-2",
        startDate: "26/3/2022",
        endDate: "26/3/2022",
        instructions: "This is a closed notes examination"
    },
    "c1-q3": {
      heading: "Quiz-3",
      startDate: "26/3/2022",
      endDate: "26/3/2022",
      instructions: "This is a closed notes examination"
    },
    "c1-q4": {
    heading: "Quiz-4",
    startDate: "26/3/2022",
    endDate: "26/3/2022",
    instructions: "This is a closed notes examination"
    }
  };
  
  document.getElementById("test-heading").innerHTML = details[id]?.heading;
  document.getElementById("test-startdate").innerHTML = details[id]?.startDate;
  document.getElementById("test-enddate").innerHTML = details[id]?.endDate; 
  document.getElementById("test-instructions").innerHTML = details[id]?.instructions; 
}

//Adding Questions
var count = 0; //Minimum 1 question needs to be added
function addQuestion()
{
    var add = document.getElementById('question');
  if(add){
    // Create a new <p> element
    var newP = document.createElement('p');
    newP.innerHTML = 'Question ' + (count + 1);

    // Create the new text box
    var newInput = document.createElement('input');
    newInput.type = 'text';
    newInput.name = 'questions[]';

    // Add the new questions
    add.appendChild(newP);
    add.appendChild(newInput);
    // Increment the count
    count+=1;
  }  
}

let sidebar = document.querySelector(".sidebar");
  let closeBtn = document.querySelector("#btn");
  let searchBtn = document.querySelector(".bx-search");

  closeBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("open");
    menuBtnChange();//calling the function(optional)
  });

  // following are the code to change sidebar button(optional)
  function menuBtnChange() {
   if(sidebar.classList.contains("open")){
     closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");//replacing the iocns class
   }else {
     closeBtn.classList.replace("bx-menu-alt-right","bx-menu");//replacing the iocns class
   }
  }


let btnEditProfile = document.getElementById("edit-profile");
let btnSubmitEdit = document.getElementById("submit-edit-profile");


let main_page = document.querySelector(".main");
let edit_profile_page = document.querySelector(".edit-profile-main");

btnEditProfile.onclick = function(){
  main_page.classList.add("inactive");
  edit_profile_page.classList.add("active");

}

$("#profileImage").click(function(e) {
  $("#imageUpload").click();
});

function fasterPreview( uploader ) {
  if ( uploader.files && uploader.files[0] ){
        $('#profileImage').attr('src', 
           window.URL.createObjectURL(uploader.files[0]) );
  }
}

$("#imageUpload").change(function(){
  fasterPreview( this );
});


